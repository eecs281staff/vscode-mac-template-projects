You must rename vscode to .vscode in the VScode UI Explorer Panel
It has to be a hidden folder 
